/** Automatically generated file. DO NOT MODIFY */
package pages.multiple.multiplepages;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}